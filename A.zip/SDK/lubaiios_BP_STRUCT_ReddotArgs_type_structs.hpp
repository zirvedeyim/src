#pragma once

//    
// PUBGM 4.2.0 iOS
// 分享: - @lubaiios 
// 生成时间 2026年01月06日 16时15分17秒
namespace SDK
{
//---------------------By lubaiios @LBAsTool---------------------------
//Script Structs
//---------------------By lubaiios @LBAsTool---------------------------

// UserDefinedStruct BP_STRUCT_ReddotArgs_type.BP_STRUCT_ReddotArgs_type
// 0x002C
struct FBP_STRUCT_ReddotArgs_type
{
	struct FString                                     Desc_0_439D61002282DEAA74C02F5C063A5C03;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_55BC6480323F81A02F5ECCBD00963A24;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Type_2_5449C9C01D6C435B74D8C98C063B50F5;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Value_3_4C03008036F08F166DD7613003B38AD5;                 // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

